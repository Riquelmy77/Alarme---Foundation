////
////  TaskViewModel.swift
////  TaskList
////
////  Created by found on 11/12/24.
////
//
//
//import Foundation
//import SwiftData
//import Combine
//
//class TaskViewModel: ObservableObject {
//    @Published var tasks: [Task] = []
//    @Published var searchText: String = ""
//    @Published var dateChoosed: Date = Date()
//    @Published var title: String = ""
//    @Published var isShowingSheet: Bool = false
//    
//    @Environment(\.modelContext) private var modelContext
//    
//    // Query para obter tarefas da base de dados (isso pode ser integrado com o SwiftData diretamente na View)
//    @Query private var tasksFromDB: [Task]
//    
//    init() {
//        self.tasks = tasksFromDB
//    }
//
//    var searchResults: [Task] {
//        if searchText.isEmpty {
//            return tasks
//        } else {
//            return tasks.filter { $0.title.contains(searchText) }
//        }
//    }
//    
//    // Função para adicionar nova tarefa
//    func addTask() {
//        if !title.isEmpty {
//            let task = Task(title: title, dateNow: dateChoosed)
//            modelContext.insert(task)
//            title = ""
//            saveContext()
//        }
//    }
//    
//    // Função para salvar as mudanças no banco de dados
//    func saveContext() {
//        do {
//            try modelContext.save()
//        } catch {
//            print("Erro ao salvar no contexto: \(error)")
//        }
//    }
//    
//    // Função para deletar tarefas
//    func deleteTasks(at offsets: IndexSet) {
//        for index in offsets {
//            modelContext.delete(tasks[index])
//        }
//        saveContext()
//    }
//}
