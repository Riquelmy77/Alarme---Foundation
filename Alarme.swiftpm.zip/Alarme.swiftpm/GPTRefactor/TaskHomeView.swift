////
////  ContentView.swift
////  TaskList
////
////  Created by found on 11/12/24.
////
//
//
//import SwiftUI
//
//struct TaskHomeView: View {
//    @StateObject private var viewModel = TaskViewModel() // Instância do ViewModel
//    
//    var body: some View {
//        NavigationStack {
//            VStack {
//                // Cabeçalho com título
//                HStack {
//                    Text("Alarm")
//                        .font(.system(size: 50, weight: .semibold))
//                    Image(systemName: "clock")
//                        .frame(width: 3, alignment: .leading)
//                }
//                
//                // Barra de pesquisa
//                Text("Alarm in ")
//                if viewModel.searchIsActive {
//                    Text("Searching for \(viewModel.searchText)")
//                        .frame(alignment: .center)
//                }
//
//                .searchable(text: $viewModel.searchText, isPresented: $viewModel.searchIsActive)
//
//                // Lista de tarefas
//                List {
//                    Section {
//                        HStack {
//                            let sec = viewModel.dateChoosed.timeIntervalSince(viewModel.dateTask)
//                            let min = sec / 60
//                            TextField("Task", text: $viewModel.title)
//                            DatePicker("", selection: $viewModel.dateChoosed, displayedComponents: .hourAndMinute)
//                            if sec < 60 {
//                                Text("\(sec)")
//                            } else if sec >= 60 && sec < 3600 {
//                                Text("\(min)")
//                            } else {
//                                Text("\(sec / 3600)")
//                            }
//
//                            Button {
//                                viewModel.addTask()
//                            } label: {
//                                Text("SAVE")
//                            }
//                        }
//                    } header: {
//                        Text("New Task")
//                    }
//                    
//                    // Exibição das tarefas
//                    Section {
//                        ForEach(viewModel.searchResults) { task in
//                            TaskView(task)
//                        }
//                        .onDelete(perform: viewModel.deleteTasks)
//                    } header: {
//                        HStack {
//                            Text("Tasks")
//                            Spacer()
//                            Button {
//                                // Ação do botão, por exemplo, para exibir a lista
//                            } label: {
//                                Image(systemName: "list.clipboard")
//                            }
//                        }
//                    } footer: {
//                        Text("TOTAL: \(viewModel.tasks.count)")
//                    }
//                }
//                .sheet(isPresented: $viewModel.isShowingSheet) {
//                    AddTaskView(isShowingSheet: $viewModel.isShowingSheet)
//                }
//            }
//        }
//    }
//}
//
//#Preview {
//    TaskHomeView()
//}
