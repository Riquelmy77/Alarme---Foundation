////
////  Task.swift
////  TaskList
////
////  Created by found on 11/12/24.
////
//
//
//import Foundation
//import SwiftData
//
//@Model
//class Task {
//    @Attribute(.primaryKey) var id: UUID  // A chave primária
//    @Attribute(.required) var title: String // O título da tarefa
//    @Attribute(.required) var isDone: Bool // A flag indicando se a tarefa foi concluída
//    @Attribute(.required) var dateNow: Date // A data associada à tarefa
//
//    // Construtor para criar uma nova Task
//    init(title: String, isDone: Bool = false, dateNow: Date) {
//        self.title = title
//        self.isDone = isDone
//        self.dateNow = dateNow
//    }
//}
