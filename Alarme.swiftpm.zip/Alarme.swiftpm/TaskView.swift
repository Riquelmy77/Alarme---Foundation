import SwiftUI

struct TaskView: View {

    let task: Task
    
    init(_ task: Task) {
     
        self.task = task
    }
    
    @State private var sec: TimeInterval = 0
    @State private var showAlert = false
    var body: some View {
        
        @State var dateTask : Date = .now
        
        let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
        
        var min: TimeInterval {
            sec / 60
        }
        
        HStack {
            VStack(alignment: .leading) {
                Text(task.title)
                Text(task.dateNow.formatted())
                    .foregroundStyle(.secondary)
            }
            Spacer()
            
            if sec <= 0 {
                Text("Alarme desativado")
            } else if sec < 60 {
                Text(String(format: "%.2f", sec) + " seg")
            } else if sec >= 60 && sec < 3600 {
                Text(String(format: "%.2f", min) + " min")
            } else if sec > 3600 {
                Text(String(format: "%.0f", sec / 3600) + " hora " + String(format: "%.0f", min / 60) + " e minutos")
            }

            
            Button {
                task.isDone.toggle()
                
                
            } label: {
                Image(systemName: task.isDone ? "checkmark.square.fill" : "square")
            }
        }.onAppear {
            sec = task.dateNow.timeIntervalSince(dateTask)
        }
        .onReceive(timer) { _ in
            if(task.isDone) {
                if sec > 0 {
                    sec -= 1
                } else if sec <= 0 {
                    showAlert = true
                    sec = 0
                }
            }
            
        }
        .alert("Alarm", isPresented:$showAlert) {
            Button("Ok",role:.cancel) {
                showAlert = false
                task.isDone = false
            }
        } message: {
            Text(task.title)
        }
    }

}
