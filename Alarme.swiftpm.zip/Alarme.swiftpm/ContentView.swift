import SwiftUI
import SwiftData


struct ContentView: View {
    @State private var searchText = ""
    @State private var searchIsActive = false
    
    @State private var dateChoosed : Date = Date()
    @Environment(\.modelContext) var modelContext
    
    @Query var tasks: [Task]
    
    @State var title = ""
    
    @State var isShowingSheet = false
                        
    
    var body: some View {
        HStack{
            Text("Alarm")
                .font(.system(size: 50, weight: .semibold))
        Image(systemName: "clock")
            .frame(width:3, alignment: .leading)
        }
    
        NavigationStack {
            Text("")
            if (searchIsActive) {
                Text("Searching for \(searchText)")
                    .frame(alignment: .center)
            }
            List {
                HStack {
                    TextField("Task", text: $title)
                    DatePicker("",selection: $dateChoosed, displayedComponents: .hourAndMinute)
                    
                    Button {
                        if(title == ""){
                            
                        } else {
                            let task = Task(title: title, dateNow: dateChoosed )
                            modelContext.insert(task)
                            
                            title = ""
                        }
                        
                    } label: {
                        Text("SAVE")
                    }
                }
                Section {
                    
                } header: {
                    Text("New Task")
                }
                
                Section {
                    ForEach(searchResults) { task in
                        TaskView(task)
                    }
                    .onDelete{i in
                        for index in i {
                            modelContext.delete(tasks[index])
                        }
                    }
                } header: {
                    HStack{
                        Text("Tasks")
                        Spacer()
                        Button{
                            
                        } label: {
                            Image(systemName: "list.clipboard")
                        }
                    }
                } footer: {
                    Text("TOTAL: \(tasks.count)")
                }
                
            }
            
        }
        .searchable(text: $searchText, isPresented: $searchIsActive)
       
        
        .sheet(isPresented: $isShowingSheet){
            AddTaskView(isShowingSheet: $isShowingSheet)
        }
    }
    
    var searchResults: [Task] {
        if searchText.isEmpty {
            return tasks
        } else {
            return tasks.filter {$0.title.contains(searchText) }
        }
    }
}


#Preview {
    ContentView()
}

