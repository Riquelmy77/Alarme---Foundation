import Foundation
import SwiftData

@Model
class Task {
    var id = UUID()
    var title: String
    var isDone: Bool
    var dateNow: Date
    
    init(title: String, isDone: Bool = false, dateNow: Date) {
        self.title = title
        self.isDone = isDone
        self.dateNow = dateNow
    }
}
