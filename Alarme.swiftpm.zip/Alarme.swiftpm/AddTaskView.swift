//
//  SwiftUIView.swift
//  TaskList
//
//  Created by found on 03/12/24.
//

import SwiftUI


struct AddTaskView: View {
    
    @Environment(\.dismiss) var dismiss
    @State var title: String = ""
    @State var dateChoosed : Date = .now
    
    @Environment(\.modelContext) var modelContext
    @Binding var isShowingSheet: Bool
    
    
    var body: some View {
        List{
            Section {
                HStack {
                    TextField("Task", text: $title)
                    
                    Button {
                        let task = Task(title: title, dateNow: dateChoosed)
                        modelContext.insert(task)
            
                        title = ""
                
                        dismiss()
                    } label: {
                        Text("SAVE")
                    }
                }
            } header: {
                Text("New Task")
            }
        }
    }
}
    
    #Preview {
        AddTaskView(isShowingSheet: .constant(true))
    }

